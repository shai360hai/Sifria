class Customer:
    def __init__(self, name, city, age, idnumber=None):
        self.idnumber = idnumber
        self.name = name
        self.city = city
        self.age = age
        
