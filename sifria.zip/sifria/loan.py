class Loan:
    def __init__(self, cust_id, book_id, loandate, returndate):
        self.cust_id = cust_id
        self.book_id = book_id
        self.loandate = loandate
        self.returndate = returndate